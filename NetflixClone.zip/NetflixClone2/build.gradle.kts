// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false

    // This line tells Gradle to look for the version 2.0.0 compiler
    // instead of searching for the old 1.9.24 version
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
}